import random

# nombre choisi par l'ordinateur
nombre = random.randint(1, 10000)

while True:
    a = int(input("Devinez le prix € : "))

    if a < nombre:
        print("plus")
    elif a > nombre:
        print("moins")
    else:
        print("Bravo !")
        break
    
    