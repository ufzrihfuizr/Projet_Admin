def demande():
    nb = input("Combien de chaussures ? ")
    print("Vous avez saisi :", nb)

demande()