def demande():
    nb = int(input("Combien de chaussures ? "))
    if nb % 2 == 0:
        print(nb, ": est pair")
    else:
        print(nb, ": est impair")

demande()